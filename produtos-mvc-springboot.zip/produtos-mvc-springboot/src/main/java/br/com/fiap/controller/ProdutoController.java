package br.com.fiap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import br.com.fiap.model.ProdutoModel.ProdutoModel;
import br.com.fiap.repository.ProdutoRepository.Repository;

@Controller
public class ProdutoController {
	Repository repository = new Repository();
	
	@RequestMapping("/produtos")
	public String findAll(Model model) {
		model.addAttribute("produtos", repository.findAll());
		return "produtos";
	}
	@RequestMapping(value = "/produto/{id}", method = RequestMethod.GET)
	public String findById(@PathVariable("id") long id, Model model) {
		model.addAttribute("produto", repository.findById(id));
		return "produto-detalhe";
	}
	
	@RequestMapping(value="/produto/new", method= RequestMethod.GET)
	public String openSave() {
		return "produto-novo";
	}
	
	@PostMapping("/produto/new")
	@RequestMapping(value= "/produto/new", method = RequestMethod.GET)
	public String save(ProdutoModel produto) {
		repository.save(produto);
		return "produto-novo-sucesso";
	}
	
	
}



