package br.com.fiap.repository.ProdutoRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import br.com.fiap.model.ProdutoModel.ProdutoModel;

public class Repository {
	private static Map<Long, ProdutoModel> produtos;
	
	public Repository() {
		produtos = new HashMap<Long, ProdutoModel>();
		
		produtos.put(1L, new ProdutoModel(1L, "Nome produto 1", "SKU1", "Descricao produto 1",100.00, "Detalhe produto 1"));
		produtos.put(2L, new ProdutoModel(1L, "Nome produto 2", "SKU2", "Descricao produto 2",200.00, "Detalhe produto 2"));
		produtos.put(3L, new ProdutoModel(1L, "Nome produto 3", "SKU3", "Descricao produto 3",300.00, "Detalhe produto 3"));
	}
	
	
	public ArrayList<ProdutoModel> findAll() {
		return new ArrayList<>(produtos.values());
		
	}
	
	public ProdutoModel findById(long id) {
		return produtos.get(id);
	}
	
	public void save(ProdutoModel produto) {
		Long newId = (long)(produtos.size() + 1);
		produto.setId(newId);
		produtos.put(newId, produto);
	}

}
